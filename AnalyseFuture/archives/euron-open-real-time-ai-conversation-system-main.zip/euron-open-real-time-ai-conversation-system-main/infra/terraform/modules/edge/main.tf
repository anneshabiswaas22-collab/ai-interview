# The public entry point: one Application Load Balancer on one host name (the app
# host). The services attach their own rules: /api/* and /up go to the API, everything
# else to the web app, so the browser only ever sees one origin and the refresh cookie
# stays first-party. Plus a TLS certificate for the name, and DNS.
#
# idle_timeout bounds how long a connection may go without a byte in either
# direction (alb_idle_timeout, the ALB's 60 s default).
#
# With CloudFront in front (allow_only_cloudfront = true), the load balancer accepts
# traffic only from CloudFront's origin-facing address ranges, and the service rules
# additionally require a secret header that only this deployment's distribution sends
# (any CloudFront distribution, including someone else's, uses those same ranges). So
# the CDN, and any WAF attached to it, cannot be bypassed.
locals {
  hostnames  = [for h in values(var.hostnames) : h]
  manage_dns = var.route53_zone_id != null
}

# ─── Certificate ─────────────────────────────────────────────────────────────

resource "aws_acm_certificate" "this" {
  count                     = var.certificate_arn == null ? 1 : 0
  domain_name               = local.hostnames[0]
  subject_alternative_names = slice(local.hostnames, 1, length(local.hostnames))
  validation_method         = "DNS"
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_route53_record" "validation" {
  for_each = var.certificate_arn == null && local.manage_dns ? {
    for o in aws_acm_certificate.this[0].domain_validation_options : o.domain_name => o
  } : {}
  zone_id         = var.route53_zone_id
  name            = each.value.resource_record_name
  type            = each.value.resource_record_type
  records         = [each.value.resource_record_value]
  ttl             = 300
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "this" {
  count                   = var.certificate_arn == null && local.manage_dns ? 1 : 0
  certificate_arn         = aws_acm_certificate.this[0].arn
  validation_record_fqdns = [for r in aws_route53_record.validation : r.fqdn]
}

locals {
  certificate_arn = var.certificate_arn != null ? var.certificate_arn : (
    local.manage_dns ? aws_acm_certificate_validation.this[0].certificate_arn : aws_acm_certificate.this[0].arn
  )
}

# ─── Load balancer ───────────────────────────────────────────────────────────

data "aws_ec2_managed_prefix_list" "cloudfront" {
  count = var.allow_only_cloudfront ? 1 : 0
  name  = "com.amazonaws.global.cloudfront.origin-facing"
}

resource "aws_security_group" "alb" {
  name        = "${var.name_prefix}-alb"
  description = "HTTPS into the load balancer"
  vpc_id      = var.vpc_id
  tags        = { Name = "${var.name_prefix}-alb" }
}

resource "aws_vpc_security_group_ingress_rule" "public" {
  #checkov:skip=CKV_AWS_260:Port 80 only answers with a 301 to HTTPS (see the http listener).
  for_each          = var.allow_only_cloudfront ? toset([]) : toset(["80", "443"])
  security_group_id = aws_security_group.alb.id
  description       = "HTTP/HTTPS from the internet (80 only redirects)"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "tcp"
  from_port         = tonumber(each.key)
  to_port           = tonumber(each.key)
}

resource "aws_vpc_security_group_ingress_rule" "cloudfront" {
  count             = var.allow_only_cloudfront ? 1 : 0
  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from CloudFront only"
  prefix_list_id    = data.aws_ec2_managed_prefix_list.cloudfront[0].id
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
}

resource "aws_lb" "this" {
  #checkov:skip=CKV2_AWS_28:WAF is attached at CloudFront (cdn module) when enabled.
  #checkov:skip=CKV_AWS_150:Deletion protection is an input (deletion_protection); aws-prod enables it.
  name                       = "${var.name_prefix}-alb"
  load_balancer_type         = "application"
  internal                   = false
  subnets                    = var.public_subnet_ids
  security_groups            = [aws_security_group.alb.id]
  drop_invalid_header_fields = true
  idle_timeout               = var.idle_timeout
  enable_deletion_protection = var.deletion_protection

  #checkov:skip=CKV_AWS_91:Access logging is opt-in via access_logs_bucket.
  dynamic "access_logs" {
    for_each = var.access_logs_bucket == null ? [] : [1]
    content {
      bucket  = var.access_logs_bucket
      prefix  = "alb"
      enabled = true
    }
  }
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}

# Unknown host names get a 404; each service adds its own host rule. Behind CloudFront
# the services' rules also require the secret origin header, so anything that reaches
# the load balancer without it (a request that bypassed the CDN) gets a 403 here.
resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = local.certificate_arn
  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = var.allow_only_cloudfront ? "Forbidden" : "Not found"
      status_code  = var.allow_only_cloudfront ? "403" : "404"
    }
  }
}

# ─── DNS (when the zone is in Route53 and no CDN takes over the names) ──────

resource "aws_route53_record" "hosts" {
  for_each = local.manage_dns && var.create_dns_records ? var.hostnames : {}
  zone_id  = var.route53_zone_id
  name     = each.value
  type     = "A"
  alias {
    name                   = aws_lb.this.dns_name
    zone_id                = aws_lb.this.zone_id
    evaluate_target_health = true
  }
}
