# Copyright 2026 GrillKit Contributors
# SPDX-License-Identifier: Apache-2.0
"""Speech feature: Whisper models, dictation, and related APIs."""
